<?php
session_start();
$con= mysqli_connect('localhost','root','','caff');
$Name = $_POST['Name'];
$People=$_POST['People'];
$date1 = $_POST['date1'];
$Message= $_POST['Message'];
$Phonenumber= $_POST['Phonenumber'];
$Payment = $_POST['Payment'];
$email = $_POST['email'];

	$reg=mysqli_query($con,"insert into coffee(Name,People,date1,Message,Phonenumber,Payment,email) values ('$Name','$People','$date1', '$Message','$Phonenumber','$Payment','$email')");
if($reg){

header("location:mp.html");
}
else{
echo"no";
}
	


?>
