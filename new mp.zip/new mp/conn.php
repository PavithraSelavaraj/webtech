<?php
if(mysqli_connect("localhost","root","","caff")){
echo("connection successful");
}
else{
echo("connection not successful");
}
?>
