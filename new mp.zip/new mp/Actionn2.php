<?php
$conn= mysqli_connect('localhost','root','','caff');
$experience1 = $_POST['experience'];
$comments1=$_POST['comments'];
$name1 = $_POST['name'];
$email1= $_POST['email'];


	$reg=mysqli_query($conn,"insert into feedback(experience,comments,Name,email) values ('$experience1','$comments1','$name1', '$email1')");
if($reg){

header("location:mp.html");
}
else{
echo"no";
}
	


?>
